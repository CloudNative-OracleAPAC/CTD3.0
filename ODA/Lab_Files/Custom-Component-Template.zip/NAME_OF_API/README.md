# Overview

The scaffolding for your OMCe-based custom component service implementation includes the following files:

  package.json - This is a standard package.json file.

  mcebots.js - The main javascript file.
  This provides the main body of the scaffold -- it implements the Bots custom components service REST API, delegating to the shell.js for most of its functionality.

  registry.js - Lists custom components managed by a component service.

  shell.js - Utility object shipped which finds and invokes custom components.

  mceboots.raml - RAML file which defines the API contract.

  examples/say_hello.js - An example custom component implemantion.

  examples/say_hello.json - A bot export which uses examples/say_hello.js custom component.


# To use this scaffolding:

- Create an OMCe API based on mceboots.raml.
- Modify the apiURL constant in mcesbots.js so it matches the URL of the GET /components endpoint of the API.
- Run npm install on your module.
- zip the directory and upload it as API implementation.
- Import examples/say_hello.json as a new Bot. Make sure to customize the the OMCe custom component service connection parameters.
